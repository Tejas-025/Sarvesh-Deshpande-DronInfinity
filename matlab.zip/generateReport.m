%% generateReport.m - Summary Report Generation (CSV & TXT)

run parameters
run aircraftSizing
run aerodynamicAnalysis
run cruisePower
run hoverPower
run batterySizing
run cgCalculation
run stabilityAnalysis
run enduranceValidation

fprintf('========================================\n');
fprintf('      12. GENERATING FINAL REPORTS      \n');
fprintf('========================================\n');

% 1. Create CSV Table Data
reportData = {
    'MTOW (kg)', MTOW;
    'Total Weight (N)', W_total;
    'Payload Mass (kg)', payload;
    'Total Wing Area (m^2)', wingArea;
    'Front Wing Area (m^2)', frontArea;
    'Rear Wing Area (m^2)', rearArea;
    'Effective Aspect Ratio', AR;
    'Wing Loading (N/m^2)', WingLoading;
    'Cruise Airspeed (m/s)', Vc;
    'Cruise Lift Coeff (CL)', CL;
    'Cruise Drag Coeff (CD)', CD;
    'Lift-to-Drag Ratio (L/D)', LoD;
    'Cruise Power Elec (W)', CruisePower_elec;
    'Hover Power Elec (W)', HoverPower_elec;
    'Battery Voltage (V)', batteryVoltage;
    'Battery Capacity (Ah)', batteryCapacity;
    'Battery Usable Energy (Wh)', Wh_usable;
    'Calculated CG (m)', X_cg;
    'Neutral Point (m)', X_np;
    'Static Margin (%)', StaticMargin * 100;
    'Cruise Endurance (hr)', TrueCruiseEndurance_hr;
    'Total Flight Range (km)', TotalRange_km
};

T_report = cell2table(reportData, 'VariableNames', {'Parameter', 'Value'});
writetable(T_report, 'UAV_Summary.csv');
fprintf('Saved CSV report to: UAV_Summary.csv\n');

% 2. Create Text Summary File
fid = fopen('UAV_Design_Report.txt', 'w');
if fid ~= -1
    fprintf(fid, '===================================================\n');
    fprintf(fid, ' TANDEM WING VTOL UAV FINE-TUNED DESIGN REPORT\n');
    fprintf(fid, ' Target MTOW: 20.0 kg\n');
    fprintf(fid, '===================================================\n\n');
    fprintf(fid, '1. WEIGHT & GEOMETRY:\n');
    fprintf(fid, '   - MTOW                  : %.2f kg (%.2f N)\n', MTOW, W_total);
    fprintf(fid, '   - Payload               : %.2f kg\n', payload);
    fprintf(fid, '   - Total Wing Area       : %.3f m^2\n', wingArea);
    fprintf(fid, '   - Aspect Ratio          : %.2f\n', AR);
    fprintf(fid, '   - Wing Loading          : %.2f N/m^2\n\n', WingLoading);
    fprintf(fid, '2. AERODYNAMICS & CRUISE:\n');
    fprintf(fid, '   - Cruise Speed          : %.1f m/s (%.1f km/h)\n', Vc, Vc*3.6);
    fprintf(fid, '   - Cruise CL             : %.4f\n', CL);
    fprintf(fid, '   - Cruise CD             : %.4f\n', CD);
    fprintf(fid, '   - L/D Ratio             : %.2f\n', LoD);
    fprintf(fid, '   - Cruise Elec Power     : %.2f W\n\n', CruisePower_elec);
    fprintf(fid, '3. VTOL HOVER PROPULSION:\n');
    fprintf(fid, '   - VTOL Rotors           : 4 x 0.71m Diameter\n');
    fprintf(fid, '   - Induced Velocity      : %.2f m/s\n', vi);
    fprintf(fid, '   - Hover Elec Power      : %.2f W\n\n', HoverPower_elec);
    fprintf(fid, '4. STABILITY & BATTERY:\n');
    fprintf(fid, '   - Battery Pack          : %.1fV %.1fAh (%.2f Wh)\n', batteryVoltage, batteryCapacity, batteryEnergy);
    fprintf(fid, '   - X-CG Location         : %.4f m\n', X_cg);
    fprintf(fid, '   - Neutral Point         : %.4f m\n', X_np);
    fprintf(fid, '   - Static Margin         : %.2f %%\n', StaticMargin*100);
    fprintf(fid, '   - Cruise Endurance      : %.2f hr (%.1f min)\n', TrueCruiseEndurance_hr, TrueCruiseEndurance_hr*60);
    fprintf(fid, '   - Total Range           : %.2f km\n', TotalRange_km);
    fprintf(fid, '===================================================\n');
    fclose(fid);
    fprintf('Saved Text report to: UAV_Design_Report.txt\n');
end

fprintf('----------------------------------------\n');
