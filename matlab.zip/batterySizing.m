%% batterySizing.m - Battery Energy Sizing & Pack Specification

run cruisePower
run hoverPower

% Mission Profile Times
t_hover_min = 5.0;  % Total hover time (takeoff + landing) in minutes
t_cruise_hr = 4.0;  % Cruise endurance target in hours

% Energy Breakdown
Wh_hover = HoverPower_elec * (t_hover_min / 60);
Wh_cruise = CruisePower_elec * t_cruise_hr;
Wh_total_required = Wh_hover + Wh_cruise;

% Battery Sizing with 15% DOD Safety Margin (Max 85% discharge)
dod_margin = 0.85;
Wh_battery_capacity = Wh_total_required / dod_margin;
Ah_battery_capacity = Wh_battery_capacity / batteryVoltage;

% Mass estimate for battery (assumes ~197.3 Wh/kg battery pack energy density)
energyDensity = 197.3; % Wh/kg
batteryMass = Wh_battery_capacity / energyDensity;

fprintf('========================================\n');
fprintf('         5. BATTERY SIZING ANALYSIS     \n');
fprintf('========================================\n');
fprintf('Nominal Pack Voltage   : %.1f V (12S LiPo)\n', batteryVoltage);
fprintf('Hover Energy (5 min)   : %.2f Wh\n', Wh_hover);
fprintf('Cruise Energy (4.0 hr) : %.2f Wh\n', Wh_cruise);
fprintf('Mission Total Energy   : %.2f Wh\n', Wh_total_required);
fprintf('Required Battery Capacity: %.2f Ah (%.2f Wh)\n', Ah_battery_capacity, Wh_battery_capacity);
fprintf('Estimated Battery Mass : %.2f kg\n', batteryMass);
fprintf('----------------------------------------\n');
