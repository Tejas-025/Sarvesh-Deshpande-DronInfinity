%% UAV Parameters - Tandem Wing VTOL UAV (MTOW = 20.0 kg)
% All physical and geometric parameters are fine-tuned for a 20 kg MTOW design.

g = 9.81;                  % Acceleration due to gravity (m/s^2)
rho = 1.225;               % Air density at sea level (kg/m^3)

%% Mission Requirements
payload = 5.0;             % Payload mass (kg)
targetEndurance = 4.0;     % Target cruise endurance (hr)
targetRange = 250e3;       % Target range (m)

%% Geometry (Tandem Wing Layout)
spanFront = 2.20;          % Front wing span (m)
spanRear = 2.04;           % Rear wing span (m)
frontArea = 0.64;          % Front wing area (m^2)
rearArea = 0.55;           % Rear wing area (m^2)

wingArea = frontArea + rearArea; % Total wing area = 1.19 m^2
span = spanFront;          % Main reference span (m)
AR_front = spanFront^2 / frontArea;  % Front wing aspect ratio = 7.5625
AR_rear = spanRear^2 / rearArea;    % Rear wing aspect ratio = 7.5625
AR = 7.5625;               % Effective aspect ratio

chordFront = frontArea / spanFront; % Mean chord front wing (m) ~ 0.291 m
chordRear = rearArea / spanRear;    % Mean chord rear wing (m) ~ 0.269 m
MAC = (chordFront * frontArea + chordRear * rearArea) / wingArea; % Total MAC ~ 0.281 m

%% Weight Specification
MTOW = 20.0;               % Maximum Take-Off Weight (kg) - STRICT REQUIREMENT
W_total = MTOW * g;        % Total Weight (N) = 196.2 N

%% Cruise Aerodynamics & Operational State
Vc = 18.0;                 % Cruise velocity (m/s) (~64.8 km/h)
CD0 = 0.030;               % Zero-lift drag coefficient
e_oswald = 0.85;           % Oswald efficiency factor
k_induced = 1 / (pi * AR * e_oswald); % Induced drag factor

%% VTOL Hover Propulsion System
hoverMotors = 4;           % 4 Quad-Rotor VTOL Motors
diskDiameter = 0.71;       % Rotor disk diameter (m) (28 inches)
diskAreaSingle = pi * (diskDiameter / 2)^2; % Single rotor disk area (m^2)
totalDiskArea = hoverMotors * diskAreaSingle; % Total rotor area ~ 1.5837 m^2
figureOfMerit = 0.68;      % Hover rotor Figure of Merit (FM)
eta_hover_esc_motor = 0.88; % Motor & ESC efficiency in hover

%% Forward Cruise Propulsion System
etaProp = 0.82;            % Pusher propeller efficiency in cruise
etaMotor = 0.92;           % Cruise motor efficiency

%% Battery & Electrical System
batteryVoltage = 44.4;     % Nominal voltage (12S LiPo / Li-ion) (V)
batteryCapacity = 32.0;    % Battery capacity (Ah)
batteryEnergy = batteryVoltage * batteryCapacity; % Nominal energy (Wh) = 1420.8 Wh
