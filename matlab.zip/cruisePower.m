%% cruisePower.m - Cruise Thrust and Power Sizing

run aerodynamicAnalysis

% Mechanical Power required to overcome drag
CruisePower_mech = Drag * Vc;

% Total Electrical Power consumed during cruise
CruisePower_elec = CruisePower_mech / (etaProp * etaMotor);

fprintf('========================================\n');
fprintf('         3. CRUISE POWER ANALYSIS       \n');
fprintf('========================================\n');
fprintf('Cruise Mechanical Power: %.2f W\n', CruisePower_mech);
fprintf('Propulsion Efficiency  : %.1f %%\n', etaProp*etaMotor*100);
fprintf('Cruise Electrical Power: %.2f W\n', CruisePower_elec);
fprintf('----------------------------------------\n');
