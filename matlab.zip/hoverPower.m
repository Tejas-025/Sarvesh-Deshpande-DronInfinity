%% hoverPower.m - VTOL Hover Momentum Theory Analysis

run parameters

% Thrust required in hover (including 5% safety margin for control authority)
hoverThrustMargin = 1.05;
T_hover_total = W_total * hoverThrustMargin;
T_per_motor = T_hover_total / hoverMotors;

% Momentum Theory Induced Velocity
vi = sqrt(T_hover_total / (2 * rho * totalDiskArea));

% Ideal Hover Power (Induced Power)
HoverPower_ideal = T_hover_total * vi;

% Actual Electrical Hover Power required
HoverPower_elec = HoverPower_ideal / (figureOfMerit * eta_hover_esc_motor);
HoverPower_per_motor = HoverPower_elec / hoverMotors;

fprintf('========================================\n');
fprintf('         4. HOVER POWER ANALYSIS        \n');
fprintf('========================================\n');
fprintf('Hover Motors           : %d units\n', hoverMotors);
fprintf('Total Disk Area        : %.4f m^2\n', totalDiskArea);
fprintf('Hover Thrust (w/ 5%% M): %.2f N (%.2f kgf)\n', T_hover_total, T_hover_total/g);
fprintf('Induced Velocity (vi)  : %.2f m/s\n', vi);
fprintf('Ideal Hover Power      : %.2f W\n', HoverPower_ideal);
fprintf('Figure of Merit (FM)   : %.2f\n', figureOfMerit);
fprintf('Total Elec Hover Power : %.2f W (%.2f W/motor)\n', HoverPower_elec, HoverPower_per_motor);
fprintf('----------------------------------------\n');
