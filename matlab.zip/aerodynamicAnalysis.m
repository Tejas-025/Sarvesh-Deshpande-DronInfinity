%% aerodynamicAnalysis.m - Cruise & Off-Design Aerodynamic Analysis

run parameters

% Cruise dynamic pressure
q_cruise = 0.5 * rho * Vc^2;

% Lift coefficient required for level cruise
CL = W_total / (q_cruise * wingArea);

% Induced drag coefficient
CDi = k_induced * CL^2;

% Total drag coefficient
CD = CD0 + CDi;

% Lift and Drag Forces
Lift = q_cruise * wingArea * CL;
Drag = q_cruise * wingArea * CD;

% Lift-to-Drag Ratio
LoD = CL / CD;

fprintf('========================================\n');
fprintf('      2. AERODYNAMIC PERFORMANCE        \n');
fprintf('========================================\n');
fprintf('Cruise Velocity (Vc)  : %.1f m/s (%.1f km/h)\n', Vc, Vc*3.6);
fprintf('Dynamic Pressure (q)  : %.2f Pa\n', q_cruise);
fprintf('Lift Coefficient (CL) : %.4f\n', CL);
fprintf('Parasitic Drag (CD0)  : %.4f\n', CD0);
fprintf('Induced Drag (CDi)    : %.4f\n', CDi);
fprintf('Total Drag Coeff (CD) : %.4f\n', CD);
fprintf('Total Lift            : %.2f N\n', Lift);
fprintf('Total Cruise Drag     : %.2f N\n', Drag);
fprintf('Lift-to-Drag Ratio    : %.2f\n', LoD);
fprintf('----------------------------------------\n');
