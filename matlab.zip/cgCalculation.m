%% cgCalculation.m - 3D Center of Gravity Location Analysis

run weightBreakdown

% Component X-location relative to nose apex (meters)
% Fuselage overall length = 1.60 m
x_loc = [
    0.50;  % Payload (Nose section)
    0.75;  % Battery Pack (Mid fuselage - adjustable for trimming)
    0.70;  % Fuselage & Structure
    0.45;  % Front Wing Aerodynamic Center (X_ac_front)
    1.25;  % Rear Wing Aerodynamic Center (X_ac_rear)
    0.80;  % VTOL Booms
    0.80;  % VTOL Motors
    1.55;  % Cruise Motor (Tail pusher)
    0.65;  % Avionics & Wiring
    0.75   % Landing Gear
];

% Moment and CG calculation
Moments = Mass .* x_loc;
X_cg = sum(Moments) / sum(Mass);

fprintf('========================================\n');
fprintf('       7. CENTER OF GRAVITY ANALYSIS    \n');
fprintf('========================================\n');
fprintf('Total UAV Mass         : %.2f kg\n', sum(Mass));
fprintf('X-CG Location from Apex: %.4f m (%.2f %% of Fuselage Length)\n', X_cg, (X_cg/1.60)*100);
fprintf('----------------------------------------\n');
