%% weightBreakdown.m - Comprehensive 20 kg MTOW Component Weight Breakdown

run parameters

Components = {
    'Payload (Sensor Bay & Gimbal)';
    'Battery Pack (12S 32Ah / Solid State)';
    'Fuselage & Center Carbon Structure';
    'Front Wing (Carbon Composite)';
    'Rear Wing (Carbon Composite)';
    'VTOL Boom Tubes & Motor Mounts';
    'VTOL Motors (4x T-Motor U8 Lite) & ESCs';
    'Cruise Pusher Motor (1x AT7224) & ESC';
    'Avionics, Flight Controller & Wiring';
    'Landing Gear & Fasteners'
};

% Mass allocation strictly summing to MTOW = 20.0 kg
Mass = [
    5.00;  % Payload
    7.20;  % Battery Pack
    1.80;  % Fuselage & Structure
    1.20;  % Front Wing
    1.00;  % Rear Wing
    0.80;  % VTOL Booms & Mounts
    1.20;  % VTOL Motors (4x 0.22kg + ESCs)
    0.60;  % Cruise Motor & ESC
    0.70;  % Avionics & Wiring
    0.50   % Landing Gear
];

Weight_N = Mass * g;
Fraction_pct = (Mass / MTOW) * 100;

T_weight = table(Components, Mass, Weight_N, Fraction_pct, ...
    'VariableNames', {'Component', 'Mass_kg', 'Weight_N', 'Percentage'});

fprintf('========================================\n');
fprintf('      6. WEIGHT BREAKDOWN ANALYSIS      \n');
fprintf('========================================\n');
disp(T_weight);
fprintf('----------------------------------------\n');
fprintf('TOTAL MTOW             : %.2f kg (%.2f N)\n', sum(Mass), sum(Weight_N));
fprintf('----------------------------------------\n');
