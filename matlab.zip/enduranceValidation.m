%% enduranceValidation.m - Endurance & Range Validation

run parameters
run batterySizing
run cruisePower
run hoverPower

% Available battery energy accounting for 85% usable DOD
Wh_usable = batteryEnergy * dod_margin;

% Subtract VTOL Hover energy (5 minutes total hover time)
Wh_hover_5min = HoverPower_elec * (5 / 60);
Wh_remaining_for_cruise = Wh_usable - Wh_hover_5min;

% True cruise endurance (hours)
TrueCruiseEndurance_hr = Wh_remaining_for_cruise / CruisePower_elec;

% True total mission time (hours)
TrueTotalMission_hr = TrueCruiseEndurance_hr + (5 / 60);

% Total Range (km)
TotalRange_km = (TrueCruiseEndurance_hr * Vc * 3600) / 1000;

fprintf('========================================\n');
fprintf('     11. ENDURANCE & RANGE VALIDATION   \n');
fprintf('========================================\n');
fprintf('Battery Usable Energy   : %.2f Wh (85%% DOD)\n', Wh_usable);
fprintf('Hover Energy (5 min)    : %.2f Wh\n', Wh_hover_5min);
fprintf('Energy for Cruise       : %.2f Wh\n', Wh_remaining_for_cruise);
fprintf('Valid Cruise Endurance  : %.2f hours (%.1f min)\n', TrueCruiseEndurance_hr, TrueCruiseEndurance_hr*60);
fprintf('Total Flight Endurance  : %.2f hours\n', TrueTotalMission_hr);
fprintf('Total Flight Range      : %.2f km\n', TotalRange_km);
fprintf('----------------------------------------\n');
