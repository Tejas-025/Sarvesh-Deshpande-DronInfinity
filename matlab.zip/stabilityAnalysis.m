%% stabilityAnalysis.m - Longitudinal Static Stability Analysis

run parameters
run cgCalculation

% Tandem Wing Geometry & AC Locations from Nose Apex
x_ac_front = 0.45; % m
x_ac_rear = 1.25;  % m

% Lift curve slopes (per rad)
CLa_front = (2 * pi * AR_front) / (2 + sqrt(4 + AR_front^2));
CLa_rear  = (2 * pi * AR_rear)  / (2 + sqrt(4 + AR_rear^2));

% Tandem wing downwash gradient at rear wing (deps/dalpha)
deps_dalpha = 0.35 * (frontArea / rearArea) * (chordRear / (x_ac_rear - x_ac_front));

% Rear wing efficiency factor
eta_rear = 0.95;

% Neutral Point Calculation for Tandem Wing (X_np)
num_np = x_ac_front * CLa_front * frontArea + x_ac_rear * CLa_rear * rearArea * eta_rear * (1 - deps_dalpha);
den_np = CLa_front * frontArea + CLa_rear * rearArea * eta_rear * (1 - deps_dalpha);

X_np = num_np / den_np;

% Static Margin relative to MAC
StaticMargin = (X_np - X_cg) / MAC;

fprintf('========================================\n');
fprintf('      8. LONGITUDINAL STABILITY         \n');
fprintf('========================================\n');
fprintf('Front Wing AC (X_ac1)  : %.3f m\n', x_ac_front);
fprintf('Rear Wing AC  (X_ac2)  : %.3f m\n', x_ac_rear);
fprintf('Downwash Gradient (deps/da): %.3f\n', deps_dalpha);
fprintf('Aircraft Neutral Point (X_np): %.4f m\n', X_np);
fprintf('Calculated Center of Gravity : %.4f m\n', X_cg);
fprintf('Static Margin (SM)     : %.2f %%\n', StaticMargin * 100);

if StaticMargin >= 0.05 && StaticMargin <= 0.25
    fprintf('STABILITY STATUS       : PASS (Statically Stable, 5%%-25%% SM)\n');
else
    fprintf('STABILITY STATUS       : WARNING (Re-trim CG needed)\n');
end
fprintf('----------------------------------------\n');
