%% performancePlots.m - Power Required & Drag Polar Curves

run parameters

V_range = linspace(8, 35, 150); % Airspeed range (m/s)

q_range = 0.5 * rho * V_range.^2;
CL_range = W_total ./ (q_range * wingArea);

CDi_range = k_induced * CL_range.^2;
CD_range = CD0 + CDi_range;

Drag_range = q_range * wingArea .* CD_range;
P_mech_range = Drag_range .* V_range;
P_elec_range = P_mech_range / (etaProp * etaMotor);

% Find Minimum Power Speed (V_mp) and Maximum Range Speed (V_mr)
[P_min, idx_mp] = min(P_elec_range);
V_mp = V_range(idx_mp);

LoD_range = CL_range ./ CD_range;
[LoD_max, idx_mr] = max(LoD_range);
V_mr = V_range(idx_mr);

fig2 = figure('Visible', 'off', 'Position', [100, 100, 900, 500]);
plot(V_range, P_elec_range, 'LineWidth', 2.5, 'Color', [0.85, 0.325, 0.098]);
hold on;
plot(V_mp, P_min, 'r*', 'MarkerSize', 10, 'LineWidth', 2);
plot(V_mr, P_elec_range(idx_mr), 'go', 'MarkerSize', 10, 'LineWidth', 2);

xlabel('Airspeed (m/s)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Electrical Power Required (W)', 'FontSize', 12, 'FontWeight', 'bold');
title('Electrical Power Required vs Airspeed (20 kg MTOW)', 'FontSize', 14, 'FontWeight', 'bold');
grid on;

legend('Power Required Curve', sprintf('Min Power Speed (%.1f m/s)', V_mp), ...
       sprintf('Max Range Speed (%.1f m/s)', V_mr), 'Location', 'northwest');

saveas(fig2, 'PowerRequired.png');
close(fig2);

fprintf('========================================\n');
fprintf('     10. PERFORMANCE PLOTS GENERATED    \n');
fprintf('========================================\n');
fprintf('Minimum Power Airspeed : %.2f m/s (%.1f W)\n', V_mp, P_min);
fprintf('Best Range Airspeed    : %.2f m/s (Max L/D = %.2f)\n', V_mr, LoD_max);
fprintf('Plot saved to: PowerRequired.png\n');
fprintf('----------------------------------------\n');
