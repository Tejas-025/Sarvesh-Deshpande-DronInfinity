% main.m - Master Execution Script for Tandem Wing VTOL UAV (MTOW = 20 kg)

clear; clc; close all;

disp('===================================================');
disp('   TANDEM WING VTOL UAV FINE-TUNED MODEL (MTOW=20kg)');
disp('===================================================');
disp(' ');

disp('1. Aircraft Sizing Analysis');
aircraftSizing;
disp(' ');

disp('2. Aerodynamic Analysis');
aerodynamicAnalysis;
disp(' ');

disp('3. Cruise Power Analysis');
cruisePower;
disp(' ');

disp('4. Hover Power Analysis');
hoverPower;
disp(' ');

disp('5. Battery Sizing');
batterySizing;
disp(' ');

disp('6. Weight Breakdown');
weightBreakdown;
disp(' ');

disp('7. Center of Gravity Calculation');
cgCalculation;
disp(' ');

disp('8. Longitudinal Stability Analysis');
stabilityAnalysis;
disp(' ');

disp('9. Generating Mission Power Profile');
missionProfile;
disp(' ');

disp('10. Generating Performance Curves');
performancePlots;
disp(' ');

disp('11. Validating Flight Endurance & Range');
enduranceValidation;
disp(' ');

disp('12. Generating UAV Summary Reports');
generateReport;
disp(' ');

disp('===================================================');
disp('   ALL ANALYSES COMPLETED SUCCESSFULLY!');
disp('===================================================');
