%% missionProfile.m - Mission Power & Energy Profile Plot

run parameters
run hoverPower
run cruisePower

% Mission Timeline (minutes)
Time_min = [0, 2, 2, 5, 5, 125, 125, 135, 135, 240, 240, 243, 243, 245];
Power_W  = [HoverPower_elec, HoverPower_elec, 1.2*HoverPower_elec, CruisePower_elec, ...
            CruisePower_elec, CruisePower_elec, CruisePower_elec, CruisePower_elec, ...
            CruisePower_elec, CruisePower_elec, 0.8*HoverPower_elec, 0.8*HoverPower_elec, ...
            HoverPower_elec, HoverPower_elec];

fig1 = figure('Visible', 'off', 'Position', [100, 100, 900, 500]);
plot(Time_min, Power_W, 'LineWidth', 2.5, 'Color', [0, 0.447, 0.741]);
xlabel('Mission Time (min)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Electrical Power Draw (W)', 'FontSize', 12, 'FontWeight', 'bold');
title('Tandem Wing VTOL UAV Mission Power Profile (MTOW = 20 kg)', 'FontSize', 14, 'FontWeight', 'bold');
grid on;
ylim([0, max(Power_W)*1.15]);

% Annotations
text(1, HoverPower_elec + 200, 'VTOL Takeoff', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');
text(120, CruisePower_elec + 200, sprintf('Cruise @ 18 m/s (%.0f W)', CruisePower_elec), 'FontWeight', 'bold');
text(244, HoverPower_elec + 200, 'VTOL Landing', 'HorizontalAlignment', 'center', 'FontWeight', 'bold');

saveas(fig1, 'MissionProfile.png');
close(fig1);

fprintf('========================================\n');
fprintf('       9. MISSION PROFILE GENERATED     \n');
fprintf('========================================\n');
fprintf('Plot saved to: MissionProfile.png\n');
fprintf('----------------------------------------\n');
