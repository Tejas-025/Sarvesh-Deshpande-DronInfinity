%% aircraftSizing.m - Geometry & Wing Sizing Analysis

run parameters

fprintf('========================================\n');
fprintf('        1. AIRCRAFT SIZING ANALYSIS     \n');
fprintf('========================================\n');

WingLoading = W_total / wingArea; % N/m^2

fprintf('MTOW                  : %.2f kg (%.2f N)\n', MTOW, W_total);
fprintf('Total Wing Area (S)   : %.3f m^2\n', wingArea);
fprintf('  - Front Wing Area   : %.3f m^2 (Span: %.2f m, Chord: %.3f m)\n', frontArea, spanFront, chordFront);
fprintf('  - Rear Wing Area    : %.3f m^2 (Span: %.2f m, Chord: %.3f m)\n', rearArea, spanRear, chordRear);
fprintf('Mean Aerodynamic Chord: %.3f m\n', MAC);
fprintf('Effective Aspect Ratio: %.2f\n', AR);
fprintf('Wing Loading (W/S)    : %.2f N/m^2 (%.2f kg/m^2)\n', WingLoading, WingLoading/g);
fprintf('----------------------------------------\n');
